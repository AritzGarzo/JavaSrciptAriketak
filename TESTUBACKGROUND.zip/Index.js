var c = document.getElementById("micanvas");
c.height = window.innerHeight;
c.width = window.innerWidth;
var cxt = c.getContext("2d");

cxt.font = "40px Calibri, Arial";
cxt.strokeText("G2mondra", 600, 120);

cxt.font = "100px Comic Sans MS, Arial";
cxt.fillText("G2mondra", 200, 400);

cxt.font = "60px Black Ops, Arial";
cxt.strokeText("G2mondra", 1050, 400);

var myVar = setInterval(setColor, 500);

function setColor() {
  var x = document.body;
  x.style.backgroundColor = x.style.backgroundColor == "yellow" ? "red" : "yellow";
}


function stopColor() {
  clearInterval(myVar);
}

