//aqui hago las array-ak de las notas de todos
let nota_Izan = [7, 3, 6];
let nota_Jorge = [3.5, 7, 4];
let nota_Urko = [10, 8, 7];
let nota_Mikel = [7.5, 5, 5.5];

let batazbestekoa_Izan = 0;
let batazbestekoa_Jorge = 0;
let batazbestekoa_Urko = 0;
let batazbestekoa_Mikel = 0;
let media = 0;

//hago la media de todas las notas

for (var i = 0; i < nota_Izan.length; i++){
  batazbestekoa_Izan = batazbestekoa_Izan + nota_Izan[i];
}
for (var i = 0; i < nota_Jorge.length; i++){
  batazbestekoa_Jorge = batazbestekoa_Jorge + nota_Jorge[i];
}
for (var i = 0; i < nota_Urko.length; i++){
  batazbestekoa_Urko = batazbestekoa_Urko + nota_Urko[i];
}
for (var i = 0; i < nota_Mikel.length; i++){
  batazbestekoa_Mikel = batazbestekoa_Mikel + nota_Mikel[i];
}

batazbestekoa_Izan = batazbestekoa_Izan / nota_Izan.length;
batazbestekoa_Jorge = batazbestekoa_Jorge / nota_Jorge.length;
batazbestekoa_Urko = batazbestekoa_Urko / nota_Urko.length;
batazbestekoa_Mikel = batazbestekoa_Mikel / nota_Mikel.length;

//cojo las medias, las relaciono con una persona y y veo a ver si han aprobado o no
let ikasleak = [
  {
    izena : 'Izan',
    media : batazbestekoa_Izan,
  },
  {
    izena : 'Jorge',
    media : batazbestekoa_Jorge,
  },
  {
    izena : 'Urko',
    media : batazbestekoa_Urko,  
  },
  {
    izena : 'Mikel',
    media : batazbestekoa_Mikel,
  }
  ]
  
let gaindituta = ikasleak.filter(ikasle => ikasle.media >= 5);
console.log(gaindituta);
document.querySelector('div').innerHTML = JSON.stringify(gaindituta);