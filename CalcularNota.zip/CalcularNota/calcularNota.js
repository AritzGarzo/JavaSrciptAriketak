let nota_Izan = [7, 3, 6];
let nota_Jorge = [3.5, 7, 4];
let nota_Urko = [10, 8, 7];
let nota_Mikel = [7.5, 5, 5.5];

function batazbestekoa(a){
  let batazbestekoa_p = 0;
  for (var i = 0; i < a.length; i++){
    batazbestekoa_p = batazbestekoa_p + a[i];
  }
    return (batazbestekoa_p / a.length);
}

let batazbestekoa_Izan = batazbestekoa(nota_Izan);
let batazbestekoa_Jorge = batazbestekoa(nota_Jorge);
let batazbestekoa_Urko = batazbestekoa(nota_Urko);
let batazbestekoa_Mikel = batazbestekoa(nota_Mikel);
let media = 0;

let ikasleak = [
  {
    izena : 'Izan',
    media : batazbestekoa_Izan,
  },
  {
    izena : 'Jorge',
    media : batazbestekoa_Jorge,
  },
  {
    izena : 'Urko',
    media : batazbestekoa_Urko,  
  },
  {
    izena : 'Mikel',
    media : batazbestekoa_Mikel,
  }
  ]
  
let gaindituta = ikasleak.filter(ikasle => ikasle.media >= 5);
console.log(gaindituta);
document.querySelector('div').innerHTML = JSON.stringify(gaindituta);