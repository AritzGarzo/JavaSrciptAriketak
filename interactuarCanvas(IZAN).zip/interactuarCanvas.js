//buscar el canvas
let canvas = document.querySelector('canvas');
 
//ajustarlo a la ventana
canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

let c = canvas.getContext('2d');


//Creo un object que se llama mouse

let Mouse ={
    x: undefined,
    y: undefined
}

let maxRadious = 40;
let minRadius = 2;
let colorArray = [
    '#C4D1D1',  
    '#EFFFFF',  
    '#EFFFFF',  
    '#EFFFFF',  
    '#D7E5E5',  
];

//creamos un event list que se va a llamar siempre que ocurra un evento
//en este caso el evento es mover el raton
//le creo una funcion dentro que se va a llamar cada vez que muevo el raton
window.addEventListener('mousemove', 
    function(event){
    Mouse.x = event.x;
    Mouse.y = event.y;
    console.log(Mouse);
})

//Ajustar el canvas al tamaño de la pantalla en todo momento.
window.addEventListener('resize', 
function(){
    canvas.height = window.innerHeight;
    canvas.width = window.innerWidth;

    init();
})

//esto es un objeto porque la primera es mayuscula 
function Circle (x,y,dx,dy,radius,minRadius)
{
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.radius = radius;
    this.minRadius = radius;
    this.color = colorArray[Math.floor(Math.random() * colorArray.length)];;

    //Cuando llame a esto dibujo un circulo
    this.draw = function()
    {
        c.beginPath();
        c.arc(this.x, this.y, this.radius, 0, 2* Math.PI, false)
        c.fill();
        c.fillStyle = this.color;
    }

    //caundo llamo a esto hago un update de la pos etc.
    this.update = function()
    {
        if(this.x + this.radius > innerWidth || this.x - this.radius < 0)
        {
            this.dx =-this.dx; //si se choca le cambio la direccion a la que se mueve
        }
    
        if(this.y + this.radius > innerHeight || this.y - this.radius < 0)
        {
            this.dy =-this.dy; //si se choca le cambio la direccion a la que se mueve
        }
        this.x+= this.dx;
        this.y+= this.dy;

        //Interacción con el raton
        if (Mouse.x - this.x < 50 && Mouse.x - this.x > -50 && Mouse.y -this.y < 50 && Mouse.y - this.y > -50)
        {
            if(this.radius < maxRadious)
            {
                this.radius +=1;
            }
        }
        else if(this.radius > this.minRadius)
        {
            this.radius -=1;
        }

        this.draw(); //llamo a la de dibujar despues de cambiar todo
    }
}

let circleArray = []; //creo un array para guardar cada circulo que cree
let acelerador = 2; //cuanto de rapido quiero que vayan
function init()
{
    circleArray = []; //La reseteo cada vez que resizeo la pantalla para que no hayan infinitos circulos

    for(let i =0; i< 1000; i++)
    {
        let radius = Math.random() * 3 + 1; //de 1 a 4
        //creo una pos random pero le sumo el radio a ambos lados para evitar qeu spawneen en la esquina de la pantalla y se queden atascados
        let x = Math.random() * (innerWidth - radius * 2)+radius;
        let y = Math.random() * (innerHeight - radius * 2)+radius;
        let dx = (Math.random()-0.5) * acelerador;
        let dy = (Math.random()-0.5) * acelerador;
        //creo un circulo y lo guardo en el array
        circleArray.push(new Circle(x,y,dx,dy,radius));
    }

}

function animate()
{
    requestAnimationFrame(animate); //se llama a si misma para animar
    c.clearRect(0,0,innerWidth,innerHeight); //limpio la pantalla cada vez

    //creo todos los circulos que estan guardados en el array
    for(let i = 0;i<circleArray.length;i++)
    {
        circleArray[i].update();
    }
}

init();
animate();